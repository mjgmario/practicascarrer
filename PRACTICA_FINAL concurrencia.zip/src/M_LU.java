public class M_LU extends Mensaje{
    
    public M_LU(){
        super(2);
    }
}
