public class M_Conf_Conexion extends Mensaje{

    public M_Conf_Conexion(){
        super(1);
    }

}