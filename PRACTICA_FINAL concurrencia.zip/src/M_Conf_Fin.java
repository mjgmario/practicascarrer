public class M_Conf_Fin extends Mensaje{
    
    public M_Conf_Fin(){
        super(9);
    }
}
