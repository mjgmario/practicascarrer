public class M_Error_Descarga extends Mensaje{
    
    public M_Error_Descarga(){
        super(12);
    }
}
