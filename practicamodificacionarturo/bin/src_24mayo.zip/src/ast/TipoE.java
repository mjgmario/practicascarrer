package ast;

public enum TipoE {
  SUMA,MUL,NUM, AND   
}
