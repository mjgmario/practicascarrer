package ast;

public enum enumtipos {
	VECTOR, BOOL, CHAR, DOUBLE, INT, PUNTERO, STRING, 
	TIPOUSUARIO
}
