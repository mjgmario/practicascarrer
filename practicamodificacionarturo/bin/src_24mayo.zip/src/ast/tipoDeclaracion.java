package ast;

public enum tipoDeclaracion {
	DECLARACIONCONVI, DECLARACIONSINVI
}
